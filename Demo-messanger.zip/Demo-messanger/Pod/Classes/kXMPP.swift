//
//  kXMPP.swift
//  OneChat
//
//  Created by Paul on 19/02/2015.
//  Copyright (c) 2015 ProcessOne. All rights reserved.
//

import Foundation

public struct kXMPP {
	public static let myJID: String = "kXMPPmyJID"
	public static let myPassword: String = "kXMPPmyPassword"
}